
const D = {"hero":"assets/img00_428d1f.jpg","imgs":{"p1":"assets/img01_4a4698.webp","p2":"assets/img02_3590d6.webp","p3":"assets/img03_09b991.webp"},"stats":[{"to":"6","plus":"+","key":"st1"},{"to":"5","plus":"+","key":"st2"},{"to":"10","plus":"+","key":"st3"},{"to":"10","plus":"+","key":"st4"}],"tools":["📐 AutoCAD","🏗️ Revit","🎨 Adobe Photoshop &amp; Illustrator","📊 Excel","🗄️ ERP Systems","🤖 AI Tools","🎬 Motion Graphics"],"logoNew":[],"uiNew":[],"socNew":[],"assets":{"brand_alfawy":"assets/img04_c5bbeb.webp","brand_boom":"assets/img05_a06b10.webp","brand_hajj":"assets/img06_9ffecb.webp","brand_kids":"assets/img07_56881a.webp","brand_makan":"assets/img08_22c75c.webp","brand_nour":"assets/img09_cf6f22.webp","brand_tea":"assets/img10_179372.jpg","cert_firstaid":"assets/img11_5d0c3a.webp","cert_iatdc":"assets/img12_835452.webp","cert_lectrobar":"assets/img13_df196f.webp","cert_security":"assets/img14_e1ce76.webp","cover_logo":"assets/img15_e80aa5.webp","cover_social":"assets/img16_b04ca5.webp","cover_uiux":"assets/img17_ae20e8.webp","logo_alfawy":"assets/img18_2785ae.webp","logo_arabiya":"assets/img19_d0ddd5.webp","logo_boom":"assets/img20_a2af74.webp","logo_hajj":"assets/img21_8f9851.webp","logo_nour":"assets/img22_ee0352.webp","logo_tea":"assets/img23_35a724.webp","soc_boom_01":"assets/img24_a1ea78.webp","soc_boom_02":"assets/img25_b78e17.webp","soc_boom_03":"assets/img26_a58f3c.webp","soc_boom_04":"assets/img27_50438f.webp","soc_kosh_01":"assets/img28_c87afd.webp","soc_kosh_02":"assets/img29_ae0f0f.webp","soc_kosh_03":"assets/img30_a59e6e.webp","soc_kosh_04":"assets/img31_2a055e.webp","soc_kosh_05":"assets/img32_1e104e.webp","soc_kosh_06":"assets/img33_ada99e.webp","soc_kosh_07":"assets/img34_068f9d.webp","soc_kosh_08":"assets/img35_957781.webp","soc_kosh_09":"assets/img36_d95e27.webp","soc_kosh_10":"assets/img37_4d9ced.webp","soc_kosh_11":"assets/img38_f86bef.webp","soc_kosh_12":"assets/img39_6ad104.webp","ui_hajj_1":"assets/img40_aef62d.webp","ui_hajj_2":"assets/img41_c859d1.webp","ui_hajj_3":"assets/img42_b1a73e.webp","ui_hajj_4":"assets/img43_ba46ed.webp","ui_hajj_5":"assets/img44_2f7c1b.webp","ui_hajj_6":"assets/img45_ceebcf.webp","ui_makan_1":"assets/img46_d8ed30.webp","ui_makan_2":"assets/img47_f60b4d.webp","ui_makan_3":"assets/img48_9a7560.webp","ui_makan_4":"assets/img49_42902a.webp","ui_makan_5":"assets/img50_cd4949.webp","ui_makan_6":"assets/img51_4dac1c.webp","soc_gym_01":"assets/img52_7f300c.webp","soc_gym_02":"assets/img53_3cb343.webp","soc_gym_03":"assets/img54_11e3f1.webp","soc_gym_04":"assets/img55_2e74d5.webp","soc_gym_05":"assets/img56_5d24bc.webp","soc_gym_06":"assets/img57_fcbadf.webp","soc_janan_01":"assets/img58_4241e9.webp","soc_janan_02":"assets/img59_288205.webp","soc_janan_03":"assets/img60_00fdc2.webp","soc_janan_04":"assets/img61_4b4228.webp","soc_janan_05":"assets/img62_e5b44a.webp","soc_janan_06":"assets/img63_c50e72.webp","soc_pickles_01":"assets/img64_67fc61.webp","soc_pickles_02":"assets/img65_6ead55.webp","soc_pickles_03":"assets/img66_4b799f.webp","soc_pickles_04":"assets/img67_b9f6a9.webp","soc_pickles_05":"assets/img68_73859b.webp","soc_pickles_06":"assets/img69_8d3685.webp","soc_afia_01":"assets/img70_ca0977.webp","soc_afia_02":"assets/img71_ccd169.webp","soc_afia_03":"assets/img72_c87267.webp","soc_afia_04":"assets/img73_f9ddc3.webp","soc_afia_05":"assets/img74_cd33a9.webp","soc_afia_06":"assets/img75_a50454.webp","ui_fitzone_1":"assets/img76_5fcf93.webp","ui_fitzone_2":"assets/img77_b6bd77.webp","ui_fitzone_3":"assets/img78_d105bf.webp","ui_fitzone_4":"assets/img79_e9bf91.webp","ui_fitzone_5":"assets/img80_96705b.webp","ui_fitzone_6":"assets/img81_34b054.webp"}};
const T = {
    en: {
      nHome: "Home", nAbout: "About", nWork: "Work", nServices: "Services", nJourney: "Journey", nContact: "Contact", nCta: "Let's Connect",
      pill: "Bachelor of Business Information Systems (BIS) · MIS Major",
      heroName: "Eng. MOHAMED ATALLAH",
      tagline: "Bridging Busway engineering, AI-driven systems and motion design.",
      ctaWork: "View Selected Work →", ctaWa: "Message on WhatsApp",
      aboutEyebrow: "About Me", aboutTitle: "Where Engineering Meets Design",
      aboutLead: "Technical Office Engineer, MIS graduate and motion designer. I draft Busway layouts, build AI-powered ERP systems and produce visuals that hold up in print and on screen.",
      storyT: "My Brief",
      story1: "My MIS background taught me to see the whole system: how data, processes and people fit together. At Lectrobar I draft Busway routing and layouts, calculate structural requirements and prepare BOQ and material takeoffs.",
      story2: "Alongside engineering, I build custom ERP systems with AI tools, automate workflows and create brand identities and motion graphics with over six years of practice.",
      chip1: "Busway Routing", chip2: "BOQ & Takeoff", chip3: "ERP & AI", chip4: "Motion Design",
      st1: "years in design & motion", st2: "Different work fields", st3: "certificates & appreciations", st4: "ERP systems built with AI",
      stackLabel: "Tools & Software",
      workEyebrow: "Selected Work", workTitle: "Drawings, Certificates & Design",
      workLead: "Busway layouts from a live project, certificates and logo design.",
      fAll: "All", fBusway: "Busway Engineering", fCerts: "Certificates", fDesign: "Logo Design",
      cat_busway: "Busway Engineering", cat_certs: "Certificates", cat_design: "Logo Design",
      p1t: "Busway General View", p1d: "3D general view of the Busway network for a monorail project: five runs between main distribution boards, LVP panels, ATS and generator box.",
      p2t: "Busway Top View", p2d: "Top view with dimensions and component details for the same project, including Busduct casings and conductor specs (3PH+FN, IP54).",
      p3t: "Certificate of Appreciation: Lectrobar", p3d: "Presented by the Chairman for exceptional technical expertise and commitment to the Technical Office team. August 2026.",
      p4t: "Certificate of Appreciation: Security Forces", p4d: "From the General Directorate of Security Forces Training, for exemplary conduct and discipline throughout military service. October 2024.",
      p5t: "Civil Defense & Fire Safety", p5d: "Participation in the civil defense and fire safety training programme at TATDC. 2020.",
      p6t: "First Aid Programme", p6d: "Completed the first aid programme at Borg El Arab hospital. 2020.",
      p7t: "Logo Design Selection", p7d: "A selection of logo and identity work across retail, hospitality, healthcare, and institutional brands.",
      svcEyebrow: "Specialties & Services", svcTitle: "What I Bring to the Table", svcLead: "Three core disciplines, one integrated approach.", lgT: "Logo Design & Branding", lgP: "Logo systems and visual identities built to be memorable, scalable, and consistent across every touchpoint.", smT: "Social Media Design", smP: "Posts, ads, and stories designed to stop the scroll and communicate one clear message on every platform.", bimT: "BIM – Electrical Busbar Routing", bimP: "Busbar routing and layout modelled in BIM, with engineering drawings and 3D models for coordination and review.", svcAlso: "Also: systems & automation", shotCap_logo: "Logo design", shotCap_social: "Social media design", shotCap_bim: "BIM drawing", phSoon: "Coming soon",
      sv1t: "Busway Layout & Technical Office", sv1p: "Routing, layout drafting, structural calculations, and BOQ/material takeoff for busway installations.",
      sv2t: "ERP & Systems with AI", sv2p: "Custom ERP modules and internal systems, built faster with AI-assisted development.",
      sv3t: "Graphic & Motion Design", sv3p: "Brand identities, logos, vector graphics and motion graphics for products and services.",
      sv4t: "AI-Assisted Workflows", sv4p: "AI tools and custom utilities that streamline engineering and business workflows.",
      jEyebrow: "My Journey", jTitle: "From Graduate to Engineer & Designer", jLead: "The path that shaped a multi-disciplinary practice.",
      j1y: "Education", j1t: "BIS Graduate (MIS Major)", j1p: "Bachelor of Business Information Systems, Damietta University.",
      j2t: "Civil Defense & Hospital Training", j2p: "Completed civil defense, fire safety and first aid programmes.",
      j3t: "Military Service", j3p: "Completed with exemplary conduct and a Certificate of Appreciation.",
      j4t: "Technical Office Engineer at Lectrobar", j4p: "Busway routing, structural calculations, BOQ and material takeoff.",
      j5y: "Now", j5t: "Engineering, AI & Design", j5p: "Combining Busway engineering, AI-driven ERP systems and motion design.",
      cEyebrow: "Contact", cTitle: "Let's build something extraordinary.",
      cLead: "Available for opportunities in Saudi Arabia. Message me directly on WhatsApp.",
      footRoles: "Technical Office Engineer · MIS & AI · Motion & Graphic Designer",
      copy: "© Eng. Mohamed Atallah. All rights reserved.",
      close: "Close", devD: "Desktop", devM: "Mobile",
      roles: ["Technical Office Engineer", "MIS & AI Specialist", "Motion & Graphic Designer"]
    },
    ar: {
      nHome: "الرئيسية", nAbout: "عني", nWork: "الأعمال", nServices: "الخدمات", nJourney: "المسيرة", nContact: "التواصل", nCta: "تواصل معي",
      pill: "بكالوريوس نظم معلومات الأعمال (BIS) · شعبة MIS",
      heroName: "م. محمد عطالله",
      tagline: "أربط بين هندسة الـ Busway وأنظمة الذكاء الاصطناعي والموشن جرافيك.",
      ctaWork: "عرض الأعمال ←", ctaWa: "راسلني على واتساب",
      aboutEyebrow: "نبذة عني", aboutTitle: "حيث تلتقي الهندسة بالتصميم",
      aboutLead: "مهندس مكتب فني وخريج نظم معلومات ومصمم موشن. أرسم مسارات الـ Busway وأبني أنظمة ERP بالذكاء الاصطناعي وأنتج تصاميم تظهر بوضوح في الطباعة والشاشات.",
      storyT: "موجزي",
      story1: "خلفيتي في نظم المعلومات علمتني أرى النظام كاملاً: كيف تترابط البيانات والعمليات والناس. في Lectrobar أرسم مسارات الـ Busway وأحسب المتطلبات الإنشائية وأعد جداول الكميات والمواد.",
      story2: "إلى جانب الهندسة، أبني أنظمة ERP مخصصة بأدوات الذكاء الاصطناعي، وأؤتمت سير العمل، وأصمم الهويات البصرية والموشن جرافيك بخبرة تزيد على ست سنوات.",
      chip1: "مسارات Busway", chip2: "BOQ وحصر الكميات", chip3: "ERP والذكاء الاصطناعي", chip4: "الموشن جرافيك",
      st1: "سنوات في التصميم والموشن", st2: "مجالات العمل المختلفة", st3: "شهادات وتقديرات", st4: "أنظمة ERP مبنية بالذكاء الاصطناعي",
      stackLabel: "الأدوات والبرامج",
      workEyebrow: "أعمال مختارة", workTitle: "رسومات وشهادات وتصميم",
      workLead: "مسارات Busway من مشروع حقيقي، وشهادات، وأعمال تصميم الشعارات.",
      fAll: "الكل", fBusway: "هندسة Busway", fCerts: "الشهادات", fDesign: "تصميم الشعارات",
      cat_busway: "هندسة Busway", cat_certs: "الشهادات", cat_design: "تصميم الشعارات",
      p1t: "Busway - المنظر العام", p1d: "منظر ثلاثي الأبعاد لشبكة الـ Busway لمشروع مونوريل: خمسة مسارات بين لوحات التوزيع الرئيسية ولوحات LVP وATS وصندوق المولد.",
      p2t: "Busway - المسقط الأفقي", p2d: "المسقط الأفقي بالأبعاد وتفاصيل المكونات للمشروع نفسه، ويشمل غلاف الـ Busduct ومواصفات الموصلات (3PH+FN، IP54).",
      p3t: "شهادة تقدير: Lectrobar", p3d: "مقدمة من رئيس مجلس الإدارة تقديراً للخبرة الفنية المتميزة والإسهام في فريق المكتب الفني. أغسطس 2026.",
      p4t: "شهادة تقدير: قوات الأمن", p4d: "من الإدارة العامة لتدريب قوات الأمن، عن حسن السير والسلوك طوال فترة الخدمة العسكرية. أكتوبر 2024.",
      p5t: "الدفاع المدني والحريق", p5d: "المشاركة في البرنامج التدريبي للدفاع المدني ومكافحة الحريق بالأكاديمية الدولية للتدريب (TATDC). 2020.",
      p6t: "برنامج الإسعافات الأولية", p6d: "اجتياز برنامج الإسعافات الأولية بمستشفى برج العرب. 2020.",
      p7t: "مختارات من تصميم الشعارات", p7d: "مجموعة من أعمال الشعارات والهويات لعلامات تجارية في التجزئة والضيافة والرعاية الصحية والمؤسسات.",
      svcEyebrow: "التخصصات والخدمات", svcTitle: "ماذا أقدم", svcLead: "ثلاثة تخصصات أساسية ونهج متكامل واحد.", lgT: "تصميم الشعارات والهوية البصرية", lgP: "أنظمة شعارات وهويات بصرية مصممة لتكون مميزة وقابلة للتوسع ومتسقة في كل نقاط التواصل.", smT: "تصميم السوشيال ميديا", smP: "بوستات وإعلانات وستوريز مصممة لإيقاف التمرير وإيصال رسالة واضحة على كل المنصات.", bimT: "BIM – توجيه مسارات الـ Busbar الكهربائية", bimP: "تخطيط وتوجيه مسارات الـ Busbar في نماذج BIM، مع الرسومات الهندسية والنماذج ثلاثية الأبعاد للتنسيق والمراجعة.", svcAlso: "وأيضاً: الأنظمة والأتمتة", shotCap_logo: "تصميم شعار", shotCap_social: "تصميم سوشيال ميديا", shotCap_bim: "رسم BIM", phSoon: "قريباً",
      sv1t: "مسارات Busway والمكتب الفني", sv1p: "التوجيه والتخطيط والحسابات الإنشائية وحصر الكميات والمواد لتركيبات الـ Busway.",
      sv2t: "ERP وأنظمة بالذكاء الاصطناعي", sv2p: "وحدات ERP وأنظمة داخلية مخصصة، تُبنى بسرعة أكبر بمساعدة الذكاء الاصطناعي.",
      sv3t: "تصميم الجرافيك والموشن", sv3p: "هويات بصرية وشعارات وفيكتور وموشن جرافيك للمنتجات والخدمات.",
      sv4t: "سير عمل بمساعدة الذكاء الاصطناعي", sv4p: "أدوات ذكاء اصطناعي ومساعدات مخصصة تسهل سير العمل الهندسي والإداري.",
      jEyebrow: "مسيرتي", jTitle: "من خريج إلى مهندس ومصمم", jLead: "المسار الذي شكّل ممارسة متعددة التخصصات.",
      j1y: "التعليم", j1t: "خريج BIS (شعبة MIS)", j1p: "بكالوريوس نظم معلومات الأعمال، جامعة دمياط.",
      j2t: "تدريب الدفاع المدني والمستشفى", j2p: "إتمام برامج الدفاع المدني والحريق والإسعافات الأولية.",
      j3t: "الخدمة العسكرية", j3p: "أتمّها بقدوة حسنة وحصلت على شهادة تقدير.",
      j4t: "مهندس مكتب فني في Lectrobar", j4p: "توجيه الـ Busway والحسابات الإنشائية وجداول الكميات والمواد.",
      j5y: "الآن", j5t: "هندسة وذكاء اصطناعي وتصميم", j5p: "الجمع بين هندسة الـ Busway وأنظمة ERP بالذكاء الاصطناعي والموشن جرافيك.",
      cEyebrow: "التواصل", cTitle: "لنبنِ شيئاً استثنائياً.",
      cLead: "متاح لفرص العمل في المملكة العربية السعودية. راسلني مباشرة على واتساب.",
      footRoles: "مهندس مكتب فني · نظم معلومات وذكاء اصطناعي · مصمم موشن وجرافيك",
      copy: "© م. محمد عطالله. جميع الحقوق محفوظة.",
      close: "إغلاق", devD: "ديسكتوب", devM: "موبايل",
      roles: ["مهندس مكتب فني", "أخصائي نظم معلومات وذكاء اصطناعي", "مصمم موشن وجرافيك"]
    }
  };
const EX = {
  en: {nBrief:"My Brief", nSkills:"Skills", nPortfolio:"Portfolio", skillsEyebrow:"Skills & Specializations", skillsTitle:"Disciplines I Work Across",
       portEyebrow:"Portfolio", portTitle:"Selected Work", cat1:"01 – Logo Design", cat2:"02 – Social Media Design", cat3:"03 – UI/UX Design",
       cat4:"04 – BIM – Electrical Busbar Routing", uiT:"UI/UX Design", uiP:"Interface design for ERP modules and internal systems, shaped around how people actually work.",
       phTitle:"Project title", phDesc:"Project description goes here.", ph:"Coming soon", socCap:"Social media design", bimB:"Engineering drawing",
       bimC:"3D model view", certTitle:"Certificates & Appreciations"},
  ar: {nBrief:"موجزي", nSkills:"المهارات", nPortfolio:"الأعمال", skillsEyebrow:"المهارات والتخصصات", skillsTitle:"التخصصات التي أعمل بها",
       portEyebrow:"الأعمال", portTitle:"أعمال مختارة", cat1:"01 – تصميم الشعارات", cat2:"02 – تصميم السوشيال ميديا", cat3:"03 – تصميم UI/UX",
       cat4:"04 – BIM – توجيه Busbar الكهربائية", uiT:"تصميم UI/UX", uiP:"تصميم واجهات وحدات ERP والأنظمة الداخلية، بما يناسب طريقة عمل المستخدمين الفعلية.",
       phTitle:"عنوان المشروع", phDesc:"وصف المشروع يكتب هنا.", ph:"قريباً", socCap:"تصميم سوشيال ميديا", bimB:"رسم هندسي",
       bimC:"عرض نموذج ثلاثي الأبعاد", certTitle:"الشهادات والتقديرات"}
};
["en","ar"].forEach(l => Object.assign(T[l], EX[l]));
const EX2 = {
  en: {portLead:"Choose a category to browse its projects.", c_logo:"Logo & Design", c_social:"Social Media", c_bim:"BIM", c_ai:"AI Tools", c_uiux:"UI/UX",
       s_logo:"Brand identities and logo systems", s_social:"Posts and campaigns for brands", s_bim:"Busbar routing and 3D engineering drawings", s_ai:"AI-powered tools and workflows", s_uiux:"App and system interfaces",
       socDesc:"A set of social media designs created for the brand.", viewFull:"View full size", closeL:"Close"},
  ar: {portLead:"اختر تصنيفاً لتصفح مشاريعه.", c_logo:"الشعارات والتصميم", c_social:"السوشيال ميديا", c_bim:"BIM", c_ai:"أدوات الذكاء الاصطناعي", c_uiux:"UI/UX",
       s_logo:"هويات بصرية وأنظمة شعارات", s_social:"بوستات وحملات لعلامات تجارية", s_bim:"مسارات Busbar ورسومات هندسية ثلاثية الأبعاد", s_ai:"أدوات وسير عمل مدعومة بالذكاء الاصطناعي", s_uiux:"واجهات تطبيقات وأنظمة",
       socDesc:"مجموعة تصميمات سوشيال ميديا للعلامة التجارية.", viewFull:"عرض بالحجم الكامل", closeL:"إغلاق"}
};
["en","ar"].forEach(l => Object.assign(T[l], EX2[l]));
const EX3 = {
  en: {c_brand:"Branding", s_brand:"Complete brand identities with real-world applications", scrLbl:"screens", postLbl:"posts", bim3t:"Busway Section View", bim3d:"Section view of the same Busway network showing the height of each run, with the joint and length schedules for Runs 1 and 2."},
  ar: {c_brand:"البراندنج", s_brand:"هويات بصرية متكاملة مع تطبيقاتها العملية", scrLbl:"صفحات", postLbl:"بوستات", bim3t:"Busway - المقطع", bim3d:"مقطع للشبكة نفسها يوضح ارتفاع كل مسار، مع جداول الوصلات والأطوال للمسارين 1 و2."}
};
["en","ar"].forEach(l => Object.assign(T[l], EX3[l]));


let lang = "en", ri = 0, roleTimer = null, ready = false, PROJ = {};
const $ = id => document.getElementById(id);
const t = k => (T[lang][k] ?? T.en[k] ?? "");
const tx = o => (typeof o === "string" ? o : (o[lang] || o.en));
const pad = n => String(n).padStart(2, "0");
const SOC = D.socNew;
const SKILLS = [
  {ic:"✒️", t:"lgT", p:"lgP"}, {ic:"📱", t:"smT", p:"smP"}, {ic:"🧭", t:"uiT", p:"uiP"}, {ic:"📐", t:"bimT", p:"bimP"}
];

const A = D.assets;
const P = (en, ar) => ({en, ar});
const BRAND = [
  {title:P("Al-Arees Tea","شاي العريس"), tags:["Branding","Packaging","Tea"], imgs:[A.brand_tea],
   desc:P("Complete identity for a premium tea brand: a turbaned character mark with Arabic calligraphy, a green, gold and cream palette, and applications on the tin, box, signage, apron, cup, bag and delivery van.",
          "هوية متكاملة لعلامة شاي فاخرة: شعار بشخصية بالعمامة مع خط عربي، وألوان الأخضر والذهبي والكريمي، وتطبيقات على العلبة المعدنية والكرتونة واللوحة والمريلة والكوب والشنطة وسيارة التوصيل.")},
  {title:P("Boom Restaurant","مطعم بوم"), tags:["Branding","Restaurant","Signage"], imgs:[A.brand_boom],
   desc:P("A bold burger-bomb identity in black, red and yellow with Montserrat lettering, applied to the storefront, polo, cap, bag, cup, box and billboard.",
          "هوية جريئة بأيقونة برجر على شكل قنبلة بألوان الأسود والأحمر والأصفر وخط Montserrat، مطبقة على الواجهة والبولو والكاب والشنطة والكوب والعلبة واللوحة الإعلانية.")},
  {title:P("Nour Voice Over","نور للتعليق الصوتي"), tags:["Branding","Audio","Studio"], imgs:[A.brand_nour],
   desc:P("A wordmark where the O becomes a microphone, in royal blue and golden yellow, shown on the studio wall, t-shirt, cap, business cards, ID badge and mug.",
          "شعار نصي يتحول فيه حرف O إلى ميكروفون بالأزرق الملكي والأصفر الذهبي، مطبق على جدار الاستوديو والتيشيرت والكاب وكروت العمل وبطاقة التعريف والمج.")},
  {title:P("Makan Delivery","مكان للتوصيل"), tags:["Branding","Delivery","App"], imgs:[A.brand_makan],
   desc:P("Identity for a food delivery app in purple and orange with a location-pin mark, applied to the app, rider gear, bag, cap, packaging, car and ad banner.",
          "هوية لتطبيق توصيل طعام بالبنفسجي والبرتقالي مع أيقونة دبوس الموقع، مطبقة على التطبيق وزي المندوب والشنطة والكاب والعبوات والسيارة والبانر الإعلاني.")},
  {title:P("Ministry of Hajj & Umrah","وزارة الحج والعمرة"), tags:["Branding","Institutional","Signage"], imgs:[A.brand_hajj],
   desc:P("Institutional identity built around a palm, the Kaaba and crossed swords in green, gold and black, applied to the vest, flag, wall signage, bag, cap, lanyard card and bus.",
          "هوية مؤسسية قائمة على النخلة والكعبة والسيفين بالأخضر والذهبي والأسود، مطبقة على الصديري والعلم واللوحة الجدارية والشنطة والكاب وبطاقة التعريف والأتوبيس.")},
  {title:P("Alfawy Poultry","الفاوي للدواجن"), tags:["Branding","Poultry","Packaging"], imgs:[A.brand_alfawy],
   desc:P("Arabic lettering shaped into a rooster, in navy and red, applied to packaging, polo, delivery truck, billboard, box, cap and bag.",
          "خط عربي مشكّل على هيئة ديك بالكحلي والأحمر، مطبق على العبوات والبولو وسيارة النقل واللوحة الإعلانية والكرتونة والكاب والشنطة.")},
  {title:P("Kids City","Kids City"), tags:["Branding","Kids","Entertainment"], imgs:[A.brand_kids],
   desc:P("A playful identity for a children's amusement park: a six-colour palette, castle gate, merchandise, banner, wayfinding signs, ticket, bag and popcorn cup.",
          "هوية مرحة لمدينة ملاهي للأطفال: ست ألوان وبوابة قلعة ومنتجات دعائية وبانر ولوحات إرشادية وتذكرة وشنطة وكوب فشار.")}
];
const LOGOS = [
  {title:P("Boom Restaurant","مطعم بوم"), tags:["Logo","Restaurant"], imgs:[A.logo_boom],
   desc:P("A burger-bomb symbol with playful bomb-style lettering, shown in white on black and in full colour.","رمز برجر على شكل قنبلة مع خط مرح بطابع القنبلة، معروض بالأبيض على الأسود وبالألوان الكاملة.")},
  {title:P("Arabiya Live","Arabiya Live"), tags:["Logo","Media"], imgs:[A.logo_arabiya],
   desc:P("The letter a shaped as a video camera with a live-broadcast signal, for a streaming brand.","حرف a مشكّل على هيئة كاميرا فيديو مع إشارة البث المباشر، لعلامة بث.")},
  {title:P("Ministry of Hajj & Umrah","وزارة الحج والعمرة"), tags:["Logo","Institutional"], imgs:[A.logo_hajj],
   desc:P("An emblem of a palm tree, the Kaaba and crossed swords, paired with bilingual lettering.","شعار من النخلة والكعبة والسيفين مع كتابة ثنائية اللغة.")},
  {title:P("Nour Voice Over","نور للتعليق الصوتي"), tags:["Logo","Audio"], imgs:[A.logo_nour],
   desc:P("A wordmark where the O doubles as a microphone, for a voice-over studio.","شعار نصي يتحول فيه حرف O إلى ميكروفون، لاستوديو تعليق صوتي.")},
  {title:P("Al-Areesh Tea","شاي العريش"), tags:["Logo","Arabic Typography"], imgs:[A.logo_tea],
   desc:P("A turbaned character in a rounded frame with Arabic calligraphy for a tea brand.","شخصية بالعمامة داخل إطار مستدير مع خط عربي لعلامة شاي.")},
  {title:P("Alfawy Poultry","الفاوي للدواجن"), tags:["Logo","Arabic Typography"], imgs:[A.logo_alfawy],
   desc:P("Arabic lettering shaped into a rooster, so the brand is easy to recognize.","خط عربي مشكّل على هيئة ديك ليسهل التعرف على العلامة.")}
];
const range = (p, n, z) => Array.from({length:n}, (_, i) => A[p + (z === false ? String(i + 1) : pad(i + 1))]);
const SOCIAL = [
  {title:P("Koshary El Tahrir","كشري التحرير"), tags:["Social Media","Food","Content"], imgs:range("soc_kosh_",12),
   desc:P("A series of social media posts for a koshary restaurant: warm food photography, Egyptian landmark illustrations and short Arabic taglines.","سلسلة بوستات سوشيال ميديا لمطعم كشري: تصوير طعام دافئ ورسوم لمعالم مصرية وعبارات عربية قصيرة.")},
  {title:P("Boom Restaurant","مطعم بوم"), tags:["Social Media","Food","Content"], imgs:range("soc_boom_",4),
   desc:P("Social media designs for a restaurant brand: bold 3D Arabic headlines over dark, warm food photography.","تصميمات سوشيال ميديا لعلامة مطاعم: عناوين عربية ثلاثية الأبعاد جريئة فوق صور طعام دافئة بخلفيات داكنة.")},
  {title:P("GoHard · Fitness Posters","GoHard · بوسترات لياقة بدنية"), tags:["Social Media","Fitness","Posters"], imgs:range("soc_gym_",6), ratio:"2 / 3",
   desc:P("Six motivational posters for a gym brand: bold brush-script headlines in yellow and white over dark, high-contrast training photography.","ستة بوسترات تحفيزية لعلامة جيم: عناوين بخط فرشاة جريء بالأصفر والأبيض فوق صور تدريب داكنة عالية التباين.")},
  {title:P("Jannan · Butter Campaign","جنان · حملة زبدة"), tags:["Social Media","Food","Campaign"], imgs:range("soc_janan_",6), ratio:"3 / 2",
   desc:P("Six social posts for a butter brand: warm family kitchen scenes, product shots and short Arabic taglines.","ستة بوستات سوشيال ميديا لعلامة زبدة: مشاهد عائلية دافئة من المطبخ، صور للمنتج وعبارات عربية قصيرة.")},
  {title:P("Heritage Pickles · Spicy Range","هيريتدج للمخللات · الحار"), tags:["Social Media","Food","Product Ads"], imgs:range("soc_pickles_",6), ratio:"2 / 3",
   desc:P("Six fiery product ads for spicy pickles: flames, chili and splash effects with bilingual Arabic and English headlines.","ستة إعلانات نارية لمخللات حارة: لهب وفلفل وتأثيرات رذاذ مع عناوين عربية وإنجليزية.")},
  {title:P("Afia · Tuna Campaign","عافية · حملة تونة"), tags:["Social Media","Food","Campaign"], imgs:range("soc_afia_",6), ratio:"2 / 3",
   desc:P("Six posts for a canned tuna brand: ocean and kitchen scenes, health benefit icons and Arabic headlines in blue and yellow.","ستة بوستات لعلامة تونة معلبة: مشاهد بحر ومطبخ وأيقونات فوائد صحية وعناوين عربية بالأزرق والأصفر.")}
];
const UIUX = [
  {title:P("Makan · Food Delivery App","مكان · تطبيق توصيل طعام"), tags:["UI/UX","Mobile","Food Delivery"], imgs:range("ui_makan_",6,false), caps:[P("Splash","شاشة البداية"),P("Product","المنتج"),P("Home","الرئيسية"),P("Settings","الإعدادات"),P("Cart","السلة"),P("Payment","الدفع")],
   desc:P("Six screens in a bold purple and orange look: splash, product page, home with offers and restaurants, settings, cart and payment.","ست صفحات بهوية بنفسجي وبرتقالي: شاشة البداية، صفحة المنتج، الرئيسية بالعروض والمطاعم، الإعدادات، السلة والدفع.")},
  {title:P("Hajj & Umrah Services App","تطبيق خدمات الحج والعمرة"), tags:["UI/UX","Mobile","Arabic RTL"], imgs:range("ui_hajj_",6,false), caps:[P("Splash","شاشة البداية"),P("Home","الرئيسية"),P("Services","الخدمات"),P("Permit details","تفاصيل التصريح"),P("Tracking","متابعة الطلب"),P("Profile","الملف الشخصي")],
   desc:P("An Arabic RTL app in green and gold: splash, home, services list, permit details with QR code, request tracking and profile.","تطبيق عربي بالأخضر والذهبي: شاشة البداية، الرئيسية، قائمة الخدمات، تفاصيل التصريح مع QR، متابعة الطلب والملف الشخصي.")},
  {title:P("FitZone · Fitness App","فيت زون · تطبيق لياقة بدنية"), tags:["UI/UX","Mobile","Fitness"], imgs:range("ui_fitzone_",6,false), caps:[P("Splash","شاشة البداية"),P("Home","الرئيسية"),P("Classes","الحصص"),P("Book a class","حجز حصة"),P("Progress","التقدم"),P("Profile","الملف الشخصي")],
   desc:P("Six screens in a dark yellow and black look: splash, home, classes, class booking, progress tracking and profile.","ست شاشات بهوية أسود وأصفر: شاشة البداية، الرئيسية، الحصص، حجز حصة، متابعة التقدم والملف الشخصي.")}
];
const cv = o => o.map(p => ({title: tx(p.title), desc: tx(p.desc), tags: p.tags, imgs: p.imgs, kind: p.kind, ratio: p.ratio, caps: (p.caps || []).map(c => tx(c))}));
const withKind = (list, kind) => list.map(p => Object.assign({}, {kind}, p));

function getProjects() {
  return {
    brand: cv(withKind(BRAND, "board")),
    logo: cv(withKind(LOGOS, "board")),
    social: cv(withKind(SOCIAL, "grid")),
    uiux: cv(withKind(UIUX, "ui")),
    ai: [
      {title: t("phTitle") + " 01", desc: t("phDesc"), tags: ["AI"], imgs: [], kind: "board"},
      {title: t("phTitle") + " 02", desc: t("phDesc"), tags: ["AI"], imgs: [], kind: "board"}
    ],
    bim: [
      {title: t("p1t"), desc: t("p1d"), tags: ["Busway", "AutoCAD", "Layout"], imgs: [D.imgs.p1], kind: "board"},
      {title: t("p2t"), desc: t("p2d"), tags: ["Busway", "AutoCAD", "BOQ"], imgs: [D.imgs.p2], kind: "board"},
      {title: t("bim3t"), desc: t("bim3d"), tags: ["Busway", "AutoCAD", "Section"], imgs: [D.imgs.p3], kind: "board"}
    ]
  };
}

const CERT_KEYS = ["p3", "p4", "p5", "p6"];
const CERT_IMG = {p3: A.cert_lectrobar, p4: A.cert_security, p5: A.cert_iatdc, p6: A.cert_firstaid};

function tile(src, label, cls = "") {
  const ph = '<span class="ph"><i>+</i>' + t("ph") + "</span>";
  return src
    ? '<div class="tile ' + cls + '" role="button" tabindex="0"><img src="' + src + '" alt="' + label + '" loading="lazy" onerror="this.parentNode.classList.add(\'noimg\');this.remove()">' + ph + "</div>"
    : '<div class="tile noimg ' + cls + '">' + ph + "</div>";
}
function card(p, cat, i) {
  return '<div class="pcard reveal" role="button" tabindex="0" data-cat="' + cat + '" data-i="' + i + '">' + tile(p.imgs[0], p.title) +
    '<div class="pbody"><h4>' + p.title + "</h4><p>" + (p.desc || "") + '</p><div class="tags">' +
    (p.tags || []).map(x => "<span>" + x + "</span>").join("") + "</div></div></div>";
}

const CATS = [
  {id:"brand",  ic:"🏷️", t:"c_brand",  s:"s_brand",  get:() => PROJ.brand,  cover:() => A.brand_tea},
  {id:"logo",   ic:"✒️", t:"c_logo",   s:"s_logo",   get:() => PROJ.logo,   cover:() => A.cover_logo},
  {id:"social", ic:"📱", t:"c_social", s:"s_social", get:() => PROJ.social, cover:() => A.cover_social},
  {id:"bim",    ic:"📐", t:"c_bim",    s:"s_bim",    get:() => PROJ.bim,    cover:() => D.imgs.p1},
  {id:"ai",     ic:"🤖", t:"c_ai",     s:"s_ai",     get:() => PROJ.ai,     cover:() => ""},
  {id:"uiux",   ic:"🧭", t:"c_uiux",   s:"s_uiux",   get:() => PROJ.uiux,   cover:() => A.cover_uiux}
];
function nProj(n) { return lang === "ar" ? (n === 1 ? "مشروع واحد" : n === 2 ? "مشروعان" : n <= 10 ? n + " مشاريع" : n + " مشروعاً") : (n === 1 ? "1 project" : n + " projects"); }
function nImg(n) { if (!n) return lang === "ar" ? "قريباً" : "Coming soon"; return lang === "ar" ? (n === 1 ? "صورة واحدة" : n === 2 ? "صورتان" : n <= 10 ? n + " صور" : n + " صورة") : (n === 1 ? "1 image" : n + " images"); }
function nCount(kind, n) {
  if (!n) return nImg(0);
  const ar = lang === "ar";
  if (kind === "ui") return ar ? (n === 1 ? "صفحة واحدة" : n === 2 ? "صفحتان" : n <= 10 ? n + " صفحات" : n + " صفحة") : n + (n === 1 ? " screen" : " screens");
  if (kind === "grid") return ar ? (n === 1 ? "بوست واحد" : n === 2 ? "بوستان" : n <= 10 ? n + " بوستات" : n + " بوست") : n + (n === 1 ? " post" : " posts");
  return nImg(n);
}
function renderCats(show) {
  $("cats").innerHTML = CATS.map(c => {
    const list = c.get(), cvr = c.cover ? c.cover() : "";
    return '<button class="cc reveal' + show + '" type="button" data-cat="' + c.id + '">' +
      (cvr ? '<span class="cc-bg"><img alt="" src="' + cvr + '"></span>' : '<span class="cc-bg empty"></span>') +
      '<span class="cc-ic">' + c.ic + '</span><span class="cc-body"><span class="cc-t">' + t(c.t) + '</span><span class="cc-s">' + t(c.s) + '</span>' +
      '<span class="cc-f"><span class="cc-n">' + nProj(list.length) + '</span><span class="cc-go">→</span></span></span></button>';
  }).join("");
}

function renderAll() {
  const show = ready ? " in" : "";
  PROJ = getProjects();
  $("skillGrid").innerHTML = SKILLS.map(s => '<div class="card skill reveal' + show + '"><div class="ic">' + s.ic + "</div><h3>" + t(s.t) + "</h3><p>" + t(s.p) + "</p></div>").join("");
  $("stats").innerHTML = D.stats.map(s => '<div class="card stat reveal' + show + '"><div class="num grad"><span class="count" data-to="' + s.to + '">' + (ready ? s.to : 0) + '</span>' + s.plus + '</div><div class="lbl">' + t(s.key) + "</div></div>").join("");
  renderCats(show);
  $("tools").innerHTML = D.tools.map(x => '<span class="tool">' + x + "</span>").join("");
  $("timeline").innerHTML = ["j1", "j2", "j3", "j4", "j5"].map(k =>
    '<div class="card tl-i reveal' + show + '"><div class="y">' + t(k + "y") + "</div><h4>" + t(k + "t") + "</h4><p>" + t(k + "p") + "</p></div>").join("");
  $("certs").innerHTML = CERT_KEYS.map((k, i) =>
    '<div class="card cert reveal' + show + '" data-ci="' + i + '" role="button" tabindex="0"><div class="cert-img"><img src="' + CERT_IMG[k] + '" alt="' + t(k + "t") + '" loading="lazy"><span class="cert-zoom">⤢</span></div><div class="cert-b"><h4>' + t(k + "t") + "</h4><p>" + t(k + "d") + "</p></div></div>").join("");
}

function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  $("langBtn").textContent = lang === "en" ? "العربية" : "English";
  $("langBtn").lang = lang === "en" ? "ar" : "en";
  $("copy").textContent = t("copy");
  document.title = lang === "en" ? "Eng. Mohamed Atallah" : "م. محمد عطالله";
  if (D.hero) $("heroImg").src = D.hero;
  renderAll();
  startRoles();
  typeName();
}

let nameTimer = null;
function typeName() {
  const el = document.querySelector(".hero .name"); if (!el) return;
  const full = t("heroName"), chars = [...full]; clearInterval(nameTimer);
  el.setAttribute("aria-label", full);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) { el.textContent = full; return; }
  el.textContent = ""; el.classList.add("typing");
  let i = 0;
  setTimeout(() => {
    nameTimer = setInterval(() => {
      i++; el.textContent = chars.slice(0, i).join("");
      if (i >= chars.length) { clearInterval(nameTimer); setTimeout(() => el.classList.remove("typing"), 1200); }
    }, 90);
  }, 350);
}
function startRoles() {
  const roles = T[lang].roles, el = $("role");
  ri = 0; el.textContent = roles[0];
  clearInterval(roleTimer);
  roleTimer = setInterval(() => {
    ri = (ri + 1) % roles.length; el.textContent = roles[ri];
    el.style.animation = "none"; void el.offsetWidth; el.style.animation = "";
  }, 2200);
}

/* viewer: project galleries, social grid and lightbox share one component */
let vItems = [], vIdx = 0;
function vShow() {
  const it = vItems[vIdx];
  if (it.title !== undefined) { $("vTitle").textContent = it.title; $("vDesc").textContent = it.desc || ""; }
  $("vImg").hidden = !it.src; $("vPh").hidden = !!it.src;
  if (it.src) $("vImg").src = it.src; else $("vImg").removeAttribute("src");
  $("vCap").textContent = it.cap || "";
  $("vCap").textContent = (it.cap ? it.cap + "   " : "") + (vIdx + 1) + " / " + vItems.length;
}
function openViewer(items, idx, title, desc) {
  vItems = items; vIdx = idx;
  $("vTitle").textContent = title || ""; $("vDesc").textContent = desc || "";
  vShow(); $("viewer").classList.add("open"); document.body.style.overflow = "hidden";
}
function closeViewer() { $("viewer").classList.remove("open"); document.body.style.overflow = scOpen() ? "hidden" : ""; $("vImg").removeAttribute("src"); }
function vStep(d) { vIdx = (vIdx + d + vItems.length) % vItems.length; vShow(); }
$("vImg").addEventListener("error", () => { $("vImg").hidden = true; $("vPh").hidden = false; });


/* ===== showcase: category -> project slides ===== */
let scList = [], scI = 0, scOpener = null, scLock = false;
const scOpen = () => $("sc").classList.contains("open");
function scSegs() {
  $("scSegs").innerHTML = scList.map((p, i) => '<button class="seg" type="button" data-i="' + i + '"></button>').join("");
  [...$("scSegs").children].forEach((b, i) => b.setAttribute("aria-label", scList[i].title));
}
function scMark() {
  [...$("scSegs").children].forEach((b, i) => b.classList.toggle("on", i === scI));
  $("scCount").textContent = pad(scI + 1) + " / " + pad(scList.length);
  const on = $("scSegs").children[scI]; if (on && on.scrollIntoView) on.scrollIntoView({inline: "center", block: "nearest"});
}
function scRender(i, dir) {
  const stage = $("scStage"), p = scList[i], rtl = lang === "ar", dx = dir * (rtl ? -1 : 1), kind = p.kind || "board";
  stage.querySelectorAll(".slide:not(.out)").forEach(o => {
    o.style.setProperty("--dx", dx); clearInterval(o.__t); o.classList.remove("in"); o.classList.add("out"); setTimeout(() => o.remove(), 520);
  });
  const el = document.createElement("article");
  el.className = "slide in kind-" + kind; el.style.setProperty("--dx", dx);
  el.innerHTML = '<div class="sl-media"></div>' +
    '<div class="sl-info"><h3></h3><p></p><div class="tags"></div><div class="sl-foot"><span class="sl-n"></span><button class="btn btn-g sl-open" type="button"></button></div></div>';
  el.querySelector("h3").textContent = p.title;
  el.querySelector("p").textContent = p.desc || "";
  el.querySelector(".tags").innerHTML = (p.tags || []).map(x => "<span>" + x + "</span>").join("");
  el.querySelector(".sl-n").textContent = nCount(kind, p.imgs.length);
  el.querySelector(".sl-open").textContent = t("viewFull");
  const media = el.querySelector(".sl-media");
  const full = k => openViewer(p.imgs.map((x, j) => ({src: x, cap: p.title + " · " + ((p.caps && p.caps[j]) || (j + 1))})), k, p.title, p.desc);
  el.querySelector(".sl-open").addEventListener("click", () => full(kind === "board" ? (media.__cur || 0) : 0));
  if (!p.imgs.length) {
    media.innerHTML = '<div class="sl-main noimg"><span class="ph"><i>+</i>' + t("ph") + '</span></div>';
    el.querySelector(".sl-open").hidden = true;
  } else if (kind === "ui") {
    const strip = document.createElement("div"); strip.className = "sl-strip";
    const n = p.imgs.length, btns = [];
    p.imgs.forEach((src, k) => {
      const w = document.createElement("div"); w.className = "scr-w"; w.style.setProperty("--k", k);
      const b = document.createElement("button"); b.type = "button"; b.className = "scr";
      b.style.setProperty("--w", Math.abs(k - (n - 1) / 2)); b.style.setProperty("--k", k);
      b.setAttribute("aria-label", p.title + " " + (k + 1));
      const im = document.createElement("img"); im.alt = p.title + " " + (k + 1); im.src = src; im.draggable = false;
      b.appendChild(im);
      const cap = document.createElement("span"); cap.className = "scr-cap";
      cap.textContent = String(k + 1).padStart(2, "0") + " · " + ((p.caps && p.caps[k]) || ""); b.appendChild(cap);
      b.addEventListener("click", () => full(k));
      b.addEventListener("pointermove", e => {
        if (e.pointerType === "touch") return;
        const r = b.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        b.style.setProperty("--ry", (x * 14).toFixed(1) + "deg"); b.style.setProperty("--rx", (-y * 10).toFixed(1) + "deg");
      });
      b.addEventListener("pointerleave", () => { b.style.setProperty("--ry", "0deg"); b.style.setProperty("--rx", "0deg"); });
      w.appendChild(b); strip.appendChild(w); btns.push(b);
    });
    media.appendChild(strip);
    let spot = 0;
    el.__t = setInterval(() => {
      if (!document.body.contains(strip) || !$("sc").classList.contains("open")) return;
      if (strip.matches(":hover") || strip.contains(document.activeElement)) { btns.forEach(x => x.classList.remove("spot")); return; }
      btns.forEach((x, j) => x.classList.toggle("spot", j === spot)); spot = (spot + 1) % btns.length;
    }, 2200);
  } else if (kind === "grid") {
    const n = p.imgs.length, cols = n <= 4 ? 4 : (n % 6 === 0 ? 6 : (n % 4 === 0 ? 4 : 3));
    const g = document.createElement("div"); g.className = "sl-grid"; g.style.setProperty("--cols", cols);
    p.imgs.forEach((src, k) => {
      const b = document.createElement("button"); b.type = "button"; b.className = "gt"; b.style.setProperty("--i", k); if (p.ratio) b.style.aspectRatio = p.ratio;
      b.setAttribute("aria-label", p.title + " " + (k + 1));
      const im = document.createElement("img"); im.alt = p.title + " " + (k + 1); im.src = src; im.loading = "lazy"; im.draggable = false;
      b.appendChild(im); b.addEventListener("click", () => full(k)); g.appendChild(b);
    });
    media.appendChild(g);
  } else {
    media.innerHTML = '<div class="sl-main" role="button" tabindex="0"><span class="sl-bg"></span><img alt=""><span class="ph"><i>+</i>' + t("ph") + '</span><span class="sl-zoom">⤢</span></div><div class="sl-thumbs"></div>';
    const main = media.querySelector(".sl-main"), img = main.querySelector("img"), bg = main.querySelector(".sl-bg"), th = media.querySelector(".sl-thumbs");
    let cur = 0;
    img.addEventListener("error", () => { main.classList.add("noimg"); img.hidden = true; });
    function setMain(k, swap) {
      cur = k; media.__cur = k; main.classList.remove("noimg"); img.hidden = false; img.alt = p.title;
      if (swap) { img.classList.remove("swap"); void img.offsetWidth; img.classList.add("swap"); }
      img.src = p.imgs[k]; bg.style.backgroundImage = 'url("' + p.imgs[k] + '")';
      [...th.children].forEach((b, j) => b.classList.toggle("on", j === k));
    }
    if (p.imgs.length > 1) {
      p.imgs.forEach((x, k) => {
        const b = document.createElement("button"); b.type = "button"; b.className = "th"; b.setAttribute("aria-label", p.title + " " + (k + 1));
        const im = document.createElement("img"); im.alt = ""; im.loading = "lazy"; im.src = x; im.addEventListener("error", () => { im.remove(); });
        b.appendChild(im); b.addEventListener("click", () => setMain(k, true)); th.appendChild(b);
      });
    } else th.hidden = true;
    main.addEventListener("click", () => { if (!main.classList.contains("noimg")) full(cur); });
    setMain(0, false);
  }
  $("scStage").appendChild(el);
  scMark();
}

function scGo(n, dir) {
  if (scLock || n === scI) return;
  scLock = true; setTimeout(() => { scLock = false; }, 380);
  scI = n; scRender(n, dir);
}
function scStep(d) { scGo((scI + d + scList.length) % scList.length, d > 0 ? 1 : -1); }
function openShowcase(id, btn) {
  const c = CATS.find(x => x.id === id); if (!c) return;
  scList = c.get(); scI = 0; scOpener = btn || null; scLock = false;
  $("scIc").textContent = c.ic; $("scT").textContent = t(c.t); $("scS").textContent = t(c.s);
  $("scClose").setAttribute("aria-label", t("closeL"));
  $("scStage").innerHTML = ""; scSegs(); scRender(0, 0);
  $("sc").classList.add("open"); document.body.style.overflow = "hidden"; $("scClose").focus();
}
function closeShowcase() {
  $("sc").classList.remove("open"); document.body.style.overflow = ""; $("scStage").innerHTML = "";
  if (scOpener && document.contains(scOpener)) scOpener.focus();
}
$("scClose").addEventListener("click", closeShowcase);
$("scPrev").addEventListener("click", () => scStep(-1));
$("scNext").addEventListener("click", () => scStep(1));
$("scSegs").addEventListener("click", e => { const b = e.target.closest(".seg"); if (b) { const n = +b.dataset.i; scGo(n, n > scI ? 1 : -1); } });
let scX = null;
$("scStage").addEventListener("touchstart", e => { scX = e.touches.length === 1 ? e.touches[0].clientX : null; }, {passive: true});
$("scStage").addEventListener("touchend", e => {
  if (scX === null) return;
  const d = e.changedTouches[0].clientX - scX; scX = null;
  if (Math.abs(d) > 60) scStep((d < 0 ? 1 : -1) * (lang === "ar" ? -1 : 1));
});

document.addEventListener("click", e => {
  const cc = e.target.closest(".cc");
  if (cc) { openShowcase(cc.dataset.cat, cc); return; }
  const ce = e.target.closest(".cert");
  if (ce) { openViewer(CERT_KEYS.map(k => ({src: CERT_IMG[k], cap: t(k + "t"), title: t(k + "t"), desc: t(k + "d")})), +ce.dataset.ci); return; }
  const pc = e.target.closest(".pcard");
  if (pc) {
    const p = PROJ[pc.dataset.cat][+pc.dataset.i];
    openViewer(p.imgs.map((src, k) => ({src, cap: p.title + " · " + (k + 1)})), 0, p.title, p.desc);
    return;
  }
  const sc = e.target.closest(".soc");
  if (sc && !sc.classList.contains("noimg")) {
    const list = [...$("gSocial").querySelectorAll(".soc")];
    openViewer(SOC.map((s, k) => ({src: s.src, cap: s.brand + " " + (k + 1)})), list.indexOf(sc), SOC[list.indexOf(sc)].brand, "");
  }
});
document.addEventListener("keydown", e => {
  if ((e.key === "Enter" || e.key === " ") && e.target.matches(".sl-main")) { e.preventDefault(); e.target.click(); }
  if (e.key === "Enter" && e.target.matches(".pcard, .tile, .cert")) e.target.click();
  if (scOpen() && !$("viewer").classList.contains("open")) {
    const f = lang === "ar" ? -1 : 1;
    if (e.key === "Escape") closeShowcase();
    if (e.key === "ArrowRight") scStep(f);
    if (e.key === "ArrowLeft") scStep(-f);
    return;
  }
  if (!$("viewer").classList.contains("open")) return;
  if (e.key === "Escape") closeViewer();
  if (e.key === "ArrowLeft") vStep(-1);
  if (e.key === "ArrowRight") vStep(1);
  if ((e.ctrlKey || e.metaKey) && ["s", "p", "u"].includes(e.key.toLowerCase())) e.preventDefault();
});
$("vClose").addEventListener("click", closeViewer);
$("vPrev").addEventListener("click", () => vStep(-1));
$("vNext").addEventListener("click", () => vStep(1));
$("viewer").addEventListener("click", e => { if (e.target === $("viewer")) closeViewer(); });
let touchX = null;
$("viewer").addEventListener("touchstart", e => { touchX = e.touches[0].clientX; }, {passive: true});
$("viewer").addEventListener("touchend", e => {
  if (touchX === null) return;
  const dx = e.changedTouches[0].clientX - touchX; touchX = null;
  if (Math.abs(dx) > 50) vStep(dx < 0 ? 1 : -1);
});
document.addEventListener("contextmenu", e => { if (e.target.closest(".tile, .pcard, .viewer, .sc, .cc, .cert")) e.preventDefault(); });

/* nav, language, mobile menu */
$("langBtn").addEventListener("click", () => {
  lang = lang === "en" ? "ar" : "en";
  try { localStorage.setItem("ma-lang", lang); } catch (err) {}
  applyLang();
});
const setMenu = o => { $("mnav").classList.toggle("open", o); $("burger").setAttribute("aria-expanded", o); $("burger").textContent = o ? "✕" : "☰"; };
$("burger").addEventListener("click", () => setMenu(!$("mnav").classList.contains("open")));
document.querySelectorAll("#mnav a").forEach(a => a.addEventListener("click", () => setMenu(false)));
document.addEventListener("keydown", e => { if (e.key === "Escape") setMenu(false); });
window.addEventListener("scroll", () => $("nav").classList.toggle("scrolled", window.scrollY > 40));

/* entrance animations and counters */
function animateCount(el) {
  const to = +el.dataset.to, start = performance.now(), dur = 1600;
  (function step(now) {
    const p = Math.min((now - start) / dur, 1);
    el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  })(start);
}
const io = new IntersectionObserver(entries => entries.forEach(en => {
  if (!en.isIntersecting) return;
  en.target.classList.add("in");
  en.target.querySelectorAll(".count").forEach(animateCount);
  io.unobserve(en.target);
}), {threshold: 0.12, rootMargin: "0px 0px -40px 0px"});
function observeAll() { document.querySelectorAll(".reveal:not(.in), .tl").forEach(el => io.observe(el)); }

document.addEventListener("pointermove", e => {
  const c = e.target.closest && e.target.closest(".cc, .cert"); if (!c) return;
  const r = c.getBoundingClientRect(); c.style.setProperty("--mx", (e.clientX - r.left) + "px"); c.style.setProperty("--my", (e.clientY - r.top) + "px");
}, {passive: true});
const prog = $("prog");
function onProg() { const h = document.documentElement.scrollHeight - innerHeight; prog.style.transform = "scaleX(" + (h > 0 ? Math.min(scrollY / h, 1) : 0) + ")"; }
addEventListener("scroll", onProg, {passive: true}); onProg();

/* active section indicator + hero parallax */
const navLinks = [...document.querySelectorAll(".links a, #mnav a")];
const spy = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return;
  navLinks.forEach(a => { const on = a.getAttribute("href") === "#" + e.target.id; a.classList.toggle("on", on); if (on) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current"); });
}), {rootMargin: "-45% 0px -50% 0px"});
document.querySelectorAll("main section[id]").forEach(x => spy.observe(x));
if (!matchMedia("(prefers-reduced-motion:reduce)").matches) {
  let pt = 0;
  addEventListener("scroll", () => { if (pt) return; pt = requestAnimationFrame(() => { pt = 0; if (scrollY < innerHeight) $("heroImg").style.setProperty("--py", (scrollY * .12).toFixed(1)); }); }, {passive: true});
}

applyLang();
try { const saved = localStorage.getItem("ma-lang"); if (saved === "ar") { lang = "ar"; applyLang(); } } catch (err) {}
ready = true;
observeAll();
